DL_UT <- function(x,y,hyp,xts=NULL,test=NULL){
  options(warn=-1)
  library(tensorflow)
  library(keras)
  if(is.null(test)){
    test=FALSE
  }
  if(test==FALSE){
    units=round((dim(x)[2])*0.7,0)#Approximating Number of Hidden layer neurons in Multiple Hidden Layer BPNN Architecture
    results=NULL
    count=1
    total=length(hyp[[1]])*length(hyp[[2]])*length(hyp[[3]])*length(hyp[[4]])*length(hyp[[5]])*length(hyp[[6]])*length(hyp[[7]])*hyp[[8]]
    for(activations in hyp[[1]]){
      for(optimizers in hyp[[2]]){
        for(epochs in hyp[[3]]){
          for(batchs in hyp[[4]]){
            for(losses in hyp[[5]]){
              for(metrics in hyp[[6]]){
                for(loss_weights in hyp[[7]]){
                  for(repetitios in 1:hyp[[8]]){

                    Post_trn=sample(1:dim(x)[1],round(dim(x)[1]*0.8))
                    X_tr = x[Post_trn,]
                    X_ts = x[-Post_trn,]

                    Mean_trn=mean(y[Post_trn])
                    SD_trn=sd(y[Post_trn])
                    y_tr =(y[Post_trn]- Mean_trn)/SD_trn
                    y_ts =(y[-Post_trn]- Mean_trn)/SD_trn

                    input <- layer_input(shape=dim(X_tr)[2])

                    base_model <- input %>%
                      layer_dense(units = units, activation = activations) %>%
                      layer_dropout(rate = 0.3) %>%
                      layer_dense(units = units, activation = activations) %>%
                      layer_dropout(rate = 0.3) %>%
                      layer_dense(units = units, activation = activations) %>%
                      layer_dropout(rate = 0.3) %>%
                      layer_dense(units = units, activation = activations) %>%
                      layer_dropout(rate = 0.3)

                    yhat <- base_model %>%
                      layer_dense(units = 1, name="yhat")

                    model <- keras_model(input,yhat) %>%
                      compile(optimizer = optimizers,
                              loss=losses,
                              metrics=metrics,
                              loss_weights=loss_weights)

                    fit(model,x=X_tr,y=y_tr,epochs=epochs,batch_size = batchs,verbose=0)
                    y_p=as.vector(predict(model,X_ts))
                    y_p=y_p*SD_trn+ Mean_trn
                    y_ts=y_ts*SD_trn+ Mean_trn

                    result=cor(y_ts, y_p)
                    results=rbind(results,cbind(activations,optimizers,epochs,batchs,losses,metrics,loss_weights,result))
                    print(paste("iteration ",count," of ",total,sep=""))
                    count=count+1
                  }
                }
              }
            }
          }
        }
      }
    }
    return(results)
  }else{

    Mean = mean(y)
    SD = sd(y)
    y = (y - Mean)/SD

    input <- layer_input(shape=dim(x)[2])
    units=round((dim(x)[2])*0.7,0)

    base_model <- input %>%
      layer_dense(units = units, activation = hyp[[1]]) %>%
      layer_dropout(rate = 0.3) %>%
      layer_dense(units = units, activation = hyp[[1]]) %>%
      layer_dropout(rate = 0.3) %>%
      layer_dense(units = units, activation = hyp[[1]]) %>%
      layer_dropout(rate = 0.3) %>%
      layer_dense(units = units, activation = hyp[[1]]) %>%
      layer_dropout(rate = 0.3)

    yhat <- base_model %>%
      layer_dense(units = 1, name="yhat")

    model <- keras_model(input,yhat) %>%
      compile(optimizer = hyp[[2]],
              loss=hyp[[5]],
              metrics=hyp[[6]],
              loss_weights=hyp[[7]])

    fit(model,x=x,y=y,epochs=hyp[[3]],batch_size = hyp[[4]],verbose=0)
    y_p=as.vector(predict(model,xts))
    y_p=y_p*SD+Mean

    return(y_p)
  }
}
