DL_MT <- function(x,y,hyp,xts=NULL,test=NULL){
  options(warn=-1)
  library(tensorflow)
  library(keras)
  if(is.null(test)){
    test=FALSE
  }
  if(test==FALSE){
    units=round((dim(x)[2])*0.7,0)#Approximating Number of Hidden layer neurons in Multiple Hidden Layer BPNN Architecture
    results=NULL
    count=1
    total=length(hyp[[1]])*length(hyp[[2]])*length(hyp[[3]])*length(hyp[[4]])*length(hyp[[5]])*length(hyp[[6]])*length(hyp[[7]])*hyp[[8]]
    for(activations in hyp[[1]]){
      for(optimizers in hyp[[2]]){
        for(epochs in hyp[[3]]){
          for(batchs in hyp[[4]]){
            for(losses in hyp[[5]]){
              for(metrics in hyp[[6]]){
                for(loss_weights in hyp[[7]]){
                  for(repetitios in 1:hyp[[8]]){

                    Post_trn=sample(1:dim(x)[1],round(dim(x)[1]*0.8))
                    X_tr = x[Post_trn,]
                    X_ts = x[-Post_trn,]

                    Mean_trn=apply(y[Post_trn,],2,mean)
                    SD_trn=apply(y[Post_trn,],2,sd)

                    y_tr=matrix(NA,ncol=dim(y)[2],nrow=dim(X_tr)[1])
                    y_ts=matrix(NA,ncol=dim(y)[2],nrow=dim(X_ts)[1])

                    for (t in 1:dim(y)[2]){
                      y_tr[,t] =(y[Post_trn,t]- Mean_trn[t])/SD_trn[t]
                      y_ts[,t] =(y[-Post_trn,t]- Mean_trn[t])/SD_trn[t]
                    }

                    input <- layer_input(shape=dim(X_tr)[2])

                    base_model <- input %>%
                      layer_dense(units = units, activation = activations) %>%
                      layer_dropout(rate = 0.3) %>%
                      layer_dense(units = units, activation = activations) %>%
                      layer_dropout(rate = 0.3) %>%
                      layer_dense(units = units, activation = activations) %>%
                      layer_dropout(rate = 0.3) %>%
                      layer_dense(units = units, activation = activations) %>%
                      layer_dropout(rate = 0.3)

                    yhat=NULL
                    loss_weights2=NULL
                    y_tr2=NULL
                    for(out_n in 1:dim(y)[2]){
                      yh <- base_model %>%
                        layer_dense(units = 1, name=paste("yhat",out_n,sep=""))
                      yhat=append(yhat,yh)
                      loss_weights2=append(loss_weights2,loss_weights)
                      y_tr2[[out_n]]=y_tr[,out_n]
                    }

                    model <- keras_model(input,yhat) %>%
                      compile(optimizer = optimizers,
                              loss=losses,
                              metrics=metrics,
                              loss_weights=loss_weights2)

                    fit(model,x=X_tr,y=y_tr2,epochs=epochs,batch_size = batchs,verbose=0)
                    y_p=predict(model,X_ts) %>%
                      data.frame() %>%
                      setNames(colnames(y))

                    for (out_n in 1:dim(y)[2]){
                      y_p[,out_n]=y_p[,out_n]*SD_trn[out_n]+ Mean_trn[out_n]
                      y_ts[,out_n]=y_ts[,out_n]*SD_trn[out_n]+ Mean_trn[out_n]
                    }

                    result=diag(cor(y_ts, y_p))
                    results=rbind(results,cbind(activations,optimizers,epochs,batchs,losses,metrics,loss_weights,result))
                    print(paste("iteration ",count," of ",total,sep=""))
                    count=count+1
                  }
                }
              }
            }
          }
        }
      }
    }
    return(results)
  }else{

    Mean=apply(y[,],2,mean)
    SD=apply(y[,],2,sd)

    y_t=matrix(NA,ncol=dim(y)[2],nrow=dim(x)[1])

    for (t in 1:dim(y)[2]){
      y_t[,t] =(y[,t]- Mean[t])/SD[t]
    }

    input <- layer_input(shape=dim(x)[2])
    units=round((dim(x)[2])*0.7,0)

    base_model <- input %>%
      layer_dense(units = units, activation = hyp[[1]]) %>%
      layer_dropout(rate = 0.3) %>%
      layer_dense(units = units, activation = hyp[[1]]) %>%
      layer_dropout(rate = 0.3) %>%
      layer_dense(units = units, activation = hyp[[1]]) %>%
      layer_dropout(rate = 0.3) %>%
      layer_dense(units = units, activation = hyp[[1]]) %>%
      layer_dropout(rate = 0.3)

    yhat=NULL
    loss_weights2=NULL
    y_t2=NULL
    for(out_n in 1:dim(y)[2]){
      yh <- base_model %>%
        layer_dense(units = 1, name=paste("yhat",out_n,sep=""))
      yhat=append(yhat,yh)
      loss_weights2=append(loss_weights2,hyp[[7]])
      y_t2[[out_n]]=y_t[,out_n]
    }

    model <- keras_model(input,yhat) %>%
      compile(optimizer = hyp[[2]],
              loss=hyp[[5]],
              metrics=hyp[[6]],
              loss_weights=loss_weights2)

    fit(model,x=x,y=y_t2,epochs=hyp[[3]],batch_size = hyp[[4]],verbose=0)
    y_p=predict(model,xts) %>%
      data.frame() %>%
      setNames(colnames(y))

    for (out_n in 1:dim(y)[2]){
      y_p[,out_n]=y_p[,out_n]*SD[out_n]+ Mean[out_n]
    }

    return(y_p)
  }
}
