DL_UT_parallel <- function(x,y,hyp,xts=NULL,test=NULL, ncores=NULL){
  options(warn=-1)
  library(reticulate)
  library(tensorflow)
  library(keras)
  library(foreach)
  library(doParallel)

  #Limit the number of threads that TensorFlow can use
  tf$config$threading$set_inter_op_parallelism_threads(1)
  tf$config$threading$set_intra_op_parallelism_threads(1)

  if(is.null(ncores)){
    numCores <- detectCores() - 1
  }else{
    numCores <- ncores
  }
  if(is.null(test)){
    test=FALSE
  }
  if(test==FALSE){
    units=round((dim(x)[2])*0.7,0)#Approximating Number of Hidden layer neurons in Multiple Hidden Layer BPNN Architecture
    total <- length(hyp[[1]])*length(hyp[[2]])*length(hyp[[3]])*length(hyp[[4]])*length(hyp[[5]])*length(hyp[[6]])*length(hyp[[7]])*hyp[[8]]
    params_list <- expand.grid(
      activations = hyp[[1]],
      optimizers = hyp[[2]],
      epochs = hyp[[3]],
      batchs = hyp[[4]],
      losses = hyp[[5]],
      metrics = hyp[[6]],
      loss_weights = hyp[[7]],
      repetitios = 1:hyp[[8]]
    )

    parallel_function <- function(params){
      activations <- params$activations
      optimizers <- params$optimizers
      epochs <- params$epochs
      batchs <- params$batchs
      losses <- params$losses
      metrics <- params$metrics
      loss_weights <- params$loss_weights
      repetitios <- params$repetitios

      Post_trn <- sample(1:dim(x)[1], round(dim(x)[1] * 0.8))
      X_tr <- x[Post_trn, ]
      X_ts <- x[-Post_trn, ]

      Mean_trn <- mean(y[Post_trn])
      SD_trn <- sd(y[Post_trn])
      y_tr <- (y[Post_trn] - Mean_trn)/SD_trn
      y_ts <- (y[-Post_trn] - Mean_trn)/SD_trn

      input <- layer_input(shape = dim(X_tr)[2])

      base_model <- input %>%
        layer_dense(units = round((dim(x)[2]) * 0.7, 0), activation = activations) %>%
        layer_dropout(rate = 0.3) %>%
        layer_dense(units = round((dim(x)[2]) * 0.7, 0), activation = activations) %>%
        layer_dropout(rate = 0.3) %>%
        layer_dense(units = round((dim(x)[2]) * 0.7, 0), activation = activations) %>%
        layer_dropout(rate = 0.3) %>%
        layer_dense(units = round((dim(x)[2]) * 0.7, 0), activation = activations) %>%
        layer_dropout(rate = 0.3)

      yhat <- base_model %>%
        layer_dense(units = 1, name = "yhat")

      model <- keras_model(input, yhat) %>%
        compile(optimizer = optimizers,
                loss = losses,
                metrics = metrics,
                loss_weights = loss_weights)

      fit(model, x = X_tr, y = y_tr, epochs = epochs, batch_size = batchs, verbose = 0)
      y_p <- as.vector(predict(model, X_ts))
      y_p <- y_p * SD_trn + Mean_trn
      y_ts <- y_ts * SD_trn + Mean_trn

      result <- cor(y_ts, y_p)
      return(c(as.character(activations), as.character(optimizers), as.character(epochs), as.character(batchs), as.character(losses), as.character(metrics), as.character(loss_weights), result))
    }

    results=NULL
    for(i in 1:((total%/%200)+1)){
      if((i*200)<=total){
        cl <- makeCluster(numCores)
        registerDoParallel(cl)
        temp <- foreach(params = iter(params_list[((i*200)-199):(i*200),], by = 'row'), .combine = rbind, .packages = c('tensorflow', 'keras')) %dopar% {
          parallel_function(params)
        }
        stopCluster(cl)
        results=rbind(results,temp)
      }else if((total%%200)!=0){
        cl <- makeCluster(numCores)
        registerDoParallel(cl)
        temp <- foreach(params = iter(params_list[((i*200)-199):total,], by = 'row'), .combine = rbind, .packages = c('tensorflow', 'keras')) %dopar% {
          parallel_function(params)
        }
        stopCluster(cl)
        results=rbind(results,temp)
      }
    }
    results <- as.data.frame(results)
    colnames(results) <- c("activations", "optimizers", "epochs", "batchs", "losses", "metrics", "loss_weights", "result")
    return(results)
  }else{

    Mean = mean(y)
    SD = sd(y)
    y = (y - Mean)/SD

    input <- layer_input(shape=dim(x)[2])
    units=round((dim(x)[2])*0.7,0)

    base_model <- input %>%
      layer_dense(units = units, activation = hyp[[1]]) %>%
      layer_dropout(rate = 0.3) %>%
      layer_dense(units = units, activation = hyp[[1]]) %>%
      layer_dropout(rate = 0.3) %>%
      layer_dense(units = units, activation = hyp[[1]]) %>%
      layer_dropout(rate = 0.3) %>%
      layer_dense(units = units, activation = hyp[[1]]) %>%
      layer_dropout(rate = 0.3)

    yhat <- base_model %>%
      layer_dense(units = 1, name="yhat")

    model <- keras_model(input,yhat) %>%
      compile(optimizer = hyp[[2]],
              loss=hyp[[5]],
              metrics=hyp[[6]],
              loss_weights=hyp[[7]])

    fit(model,x=x,y=y,epochs=hyp[[3]],batch_size = hyp[[4]],verbose=0)
    y_p=as.vector(predict(model,xts))
    y_p=y_p*SD+Mean

    return(y_p)
  }
}
