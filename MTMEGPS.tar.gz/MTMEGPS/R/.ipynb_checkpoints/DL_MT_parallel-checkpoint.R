DL_MT_parallel <- function(x,y,hyp,xts=NULL,test=NULL, ncores=NULL){
  options(warn=-1)
  library(reticulate)
  library(tensorflow)
  library(keras)
  library(foreach)
  library(doParallel)

  #Limit the number of threads that TensorFlow can use
  tf$config$threading$set_inter_op_parallelism_threads(1)
  tf$config$threading$set_intra_op_parallelism_threads(1)

  if(is.null(ncores)){
    numCores <- detectCores() - 5
  }else{
    numCores <- ncores
  }
  if(is.null(test)){
    test=FALSE
  }
  if(test==FALSE){
    units=round((dim(x)[2])*0.7,0)
    total <- length(hyp[[1]]) * length(hyp[[2]]) * length(hyp[[3]]) * length(hyp[[4]]) * length(hyp[[5]]) * length(hyp[[6]]) * length(hyp[[7]]) * hyp[[8]]
    params_list <- expand.grid(
      activations = hyp[[1]],
      optimizers = hyp[[2]],
      epochs = hyp[[3]],
      batchs = hyp[[4]],
      losses = hyp[[5]],
      metrics = hyp[[6]],
      loss_weights = hyp[[7]],
      repetitios = 1:hyp[[8]]
    )

#######revisar
    create_model <- function(input_shape, activations) {
      input <- layer_input(shape = input_shape)
      base_model <- input %>%
        layer_dense(units = round((input_shape) * 0.7, 0), activation = activations) %>%
        layer_dropout(rate = 0.3) %>%
        layer_dense(units = round((input_shape) * 0.7, 0), activation = activations) %>%
        layer_dropout(rate = 0.3) %>%
        layer_dense(units = round((input_shape) * 0.7, 0), activation = activations) %>%
        layer_dropout(rate = 0.3) %>%
        layer_dense(units = round((input_shape) * 0.7, 0), activation = activations) %>%
        layer_dropout(rate = 0.3) %>%
        layer_dense(units = 1, name = "yhat")

      model <- keras_model(input, base_model)
      return(model)
    }

###########
    parallel_function <- function(params) {
      activations <- params$activations
      optimizers <- params$optimizers
      epochs <- params$epochs
      batchs <- params$batchs
      losses <- params$losses
      metrics <- params$metrics
      loss_weights <- params$loss_weights
      repetitios <- params$repetitios

      Post_trn=sample(1:dim(x)[1],round(dim(x)[1]*0.8))
      X_tr = x[Post_trn,]
      X_ts = x[-Post_trn,]

      Mean_trn=apply(y[Post_trn,],2,mean)
      SD_trn=apply(y[Post_trn,],2,sd)

      y_tr=matrix(NA,ncol=dim(y)[2],nrow=dim(X_tr)[1])
      y_ts=matrix(NA,ncol=dim(y)[2],nrow=dim(X_ts)[1])

      for (t in 1:dim(y)[2]){
        y_tr[,t] =(y[Post_trn,t]- Mean_trn[t])/SD_trn[t]
        y_ts[,t] =(y[-Post_trn,t]- Mean_trn[t])/SD_trn[t]
      }

      input <- layer_input(shape = dim(X_tr)[2])

      base_model <- input %>%
        layer_dense(units = units, activation = activations) %>%
        layer_dropout(rate = 0.3) %>%
        layer_dense(units = units, activation = activations) %>%
        layer_dropout(rate = 0.3) %>%
        layer_dense(units = units, activation = activations) %>%
        layer_dropout(rate = 0.3) %>%
        layer_dense(units = units, activation = activations) %>%
        layer_dropout(rate = 0.3)

      yhat=NULL
      loss_weights2=NULL
      y_tr2=NULL
      for(out_n in 1:dim(y)[2]){
        yh <- base_model %>%
          layer_dense(units = 1, name=paste("yhat",out_n,sep=""))
        yhat=append(yhat,yh)
        loss_weights2=append(loss_weights2,loss_weights)
        y_tr2[[out_n]]=y_tr[,out_n]
      }

      model <- keras_model(input,yhat) %>%
        compile(optimizer = optimizers,
                loss=losses,
                metrics=metrics,
                loss_weights=loss_weights2)

      fit(model,x=X_tr,y=y_tr2,epochs=epochs,batch_size = batchs,verbose=0)
      y_p=predict(model,X_ts) %>%
        data.frame() %>%
        setNames(colnames(y))

      for (out_n in 1:dim(y)[2]){
        y_p[,out_n]=y_p[,out_n]*SD_trn[out_n]+ Mean_trn[out_n]
        y_ts[,out_n]=y_ts[,out_n]*SD_trn[out_n]+ Mean_trn[out_n]
      }

      result=diag(cor(y_ts, y_p))
      return(c(as.character(activations), as.character(optimizers), as.character(epochs), as.character(batchs), as.character(losses), as.character(metrics), as.character(loss_weights), result))
    }

    results=NULL
    for(i in 1:((total%/%200)+1)){
      if((i*200)<=total){
        cl <- makeCluster(numCores)
        registerDoParallel(cl)
        temp <- foreach(params = iter(params_list[((i*200)-199):(i*200),], by = 'row'), .combine = rbind, .packages = c('tensorflow', 'keras')) %dopar% {
          parallel_function(params)
        }
        stopCluster(cl)
        results=rbind(results,temp)
      }else if((total%%200)!=0){
        cl <- makeCluster(numCores)
        registerDoParallel(cl)
        temp <- foreach(params = iter(params_list[((i*200)-199):total,], by = 'row'), .combine = rbind, .packages = c('tensorflow', 'keras')) %dopar% {
          parallel_function(params)
        }
        stopCluster(cl)
        results=rbind(results,temp)
      }
    }
    results <- as.data.frame(results)
    temp=NULL
    for(i in 1:ncol(y)){
      temp=rbind(temp,cbind(results[,1:7],results[,(7+i)]))
    }
    results=temp
    colnames(results) <- c("activations", "optimizers", "epochs", "batchs", "losses", "metrics", "loss_weights", "result")
    return(results)
  }else{

    Mean=apply(y[,],2,mean)
    SD=apply(y[,],2,sd)

    y_t=matrix(NA,ncol=dim(y)[2],nrow=dim(x)[1])

    for (t in 1:dim(y)[2]){
      y_t[,t] =(y[,t]- Mean[t])/SD[t]
    }

    input <- layer_input(shape=dim(x)[2])
    units=round((dim(x)[2])*0.7,0)

    base_model <- input %>%
      layer_dense(units = units, activation = hyp[[1]]) %>%
      layer_dropout(rate = 0.3) %>%
      layer_dense(units = units, activation = hyp[[1]]) %>%
      layer_dropout(rate = 0.3) %>%
      layer_dense(units = units, activation = hyp[[1]]) %>%
      layer_dropout(rate = 0.3) %>%
      layer_dense(units = units, activation = hyp[[1]]) %>%
      layer_dropout(rate = 0.3)

    yhat=NULL
    loss_weights2=NULL
    y_t2=NULL
    for(out_n in 1:dim(y)[2]){
      yh <- base_model %>%
        layer_dense(units = 1, name=paste("yhat",out_n,sep=""))
      yhat=append(yhat,yh)
      loss_weights2=append(loss_weights2,hyp[[7]])
      y_t2[[out_n]]=y_t[,out_n]
    }

    model <- keras_model(input,yhat) %>%
      compile(optimizer = hyp[[2]],
              loss=hyp[[5]],
              metrics=hyp[[6]],
              loss_weights=loss_weights2)

    fit(model,x=x,y=y_t2,epochs=hyp[[3]],batch_size = hyp[[4]],verbose=0)
    y_p=predict(model,xts) %>%
      data.frame() %>%
      setNames(colnames(y))

    for (out_n in 1:dim(y)[2]){
      y_p[,out_n]=y_p[,out_n]*SD[out_n]+ Mean[out_n]
    }

    return(y_p)
  }
}
