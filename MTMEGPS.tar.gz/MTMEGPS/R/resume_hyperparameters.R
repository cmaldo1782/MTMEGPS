resume_hyperparameters <- function(results,reps,MT=NULL,name_plot=NULL){
  library(agricolae)
  library(ggplot2)
  library(cowplot)
  library(dplyr)
  library(stringr)


#funciones
  plots <- function(df){
    y_h=max(df$Accuracy)*0.1
    ggplot(df, aes(row.names(df), Accuracy)) +
      geom_bar(stat = "identity", width=0.8, alpha=0.8, fill = "steelblue") +
      geom_errorbar(aes(ymin=Accuracy-SE, ymax=Accuracy+SE), width = 0.2, color = "steelblue4") +
      theme_bw() +
      theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
      theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1))+
      labs(x = colnames(df)[4])+
      geom_text(aes(label=groups), nudge_x = 0.15, nudge_y = y_h, size = 5, color = "steelblue4")
  }

  anova_split <- function(results,reps,traits=NULL){
    group <- results %>%
      group_by(concatenate) %>%
      summarise(mean = mean(result, na.rm = TRUE),sd = sd(result, na.rm = TRUE)) %>%
      arrange(desc(mean))

    if(is.null(traits)){
      traits=1
    }

    anova=aov(result~concatenate,results[results$concatenate %in% group$concatenate[1:20],])
    groups=HSD.test(anova,"concatenate")
    r_anova=groups$groups

    fac=sqrt(traits*reps)
    r_anova_f=NULL
    for(i in 1:20){
      parts=str_split(rownames(r_anova)[i], "__")[[1]]
      r_anova_f=rbind(r_anova_f,cbind(parts[1],parts[2],parts[3],parts[4],parts[5],parts[6],parts[7],r_anova[i,],(group[group$concatenate==rownames(r_anova)[i],"sd"]/fac)))
    }
    r_anova_f=as.data.frame(r_anova_f)
    rownames(r_anova_f)=NULL
    colnames(r_anova_f)=c("activations", "optimizers", "epochs", "batchs", "losses", "metrics", "loss_weights","Accuracy","Group Tukey","SE")

    return(r_anova_f)
  }

##### comandos

  results=as.data.frame(results)
  results$result=as.numeric(results$result)
  results$concatenate=paste(results$activations,"__",results$optimizers,"__",results$epochs,"__",results$batchs,"__",results$losses,"__",results$metrics,"__",results$loss_weights,sep="")

  if(length(unique(results$activations))==1){
    r_activations=data.frame("result"=mean(results[,"result"],na.rm=T),"groups"="a")
    rownames(r_activations)=results$activations[1]
  }else{
    anova=aov(result~activations,data=results[,c("activations","result")])
    groups=HSD.test(anova,"activations")
    r_activations=groups$groups
  }
  for(x in rownames(r_activations)){
    r_activations[x,"SE"]=sd(results[results$activations==x,"result"],na.rm=T)/sqrt(length(results[results$activations==x,"result"]))
    r_activations[x,"Activation Function"]=x
  }
  colnames(r_activations)[1]="Accuracy"
  p1=plots(r_activations)
##################
  if(length(unique(results$optimizers))==1){
    r_optimizers=data.frame("result"=mean(results[,"result"],na.rm=T),"groups"="a")
    rownames(r_optimizers)=results$optimizers[1]
  }else{
    anova=aov(result~optimizers,data=results[,c("optimizers","result")])
    groups=HSD.test(anova,"optimizers")
    r_optimizers=groups$groups
  }
  for(x in rownames(r_optimizers)){
    r_optimizers[x,"SE"]=sd(results[results$optimizers==x,"result"],na.rm=T)/sqrt(length(results[results$optimizers==x,"result"]))
    r_optimizers[x,"Optimizer"]=x
  }
  colnames(r_optimizers)[1]="Accuracy"
  p2=plots(r_optimizers)

  if(length(unique(results$epochs))==1){
    r_epochs=data.frame("result"=mean(results[,"result"],na.rm=T),"groups"="a")
    rownames(r_epochs)=results$epochs[1]
  }else{
    anova=aov(result~epochs,data=results[,c("epochs","result")])
    groups=HSD.test(anova,"epochs")
    r_epochs=groups$groups
  }
  for(x in rownames(r_epochs)){
    r_epochs[x,"SE"]=sd(results[results$epochs==x,"result"],na.rm=T)/sqrt(length(results[results$epochs==x,"result"]))
    r_epochs[x,"Epoch"]=x
  }
  colnames(r_epochs)[1]="Accuracy"
  p3=plots(r_epochs)

  if(length(unique(results$batchs))==1){
    r_batchs=data.frame("result"=mean(results[,"result"],na.rm=T),"groups"="a")
    rownames(r_batchs)=results$batchs[1]
  }else{
    anova=aov(result~batchs,data=results[,c("batchs","result")])
    groups=HSD.test(anova,"batchs")
    r_batchs=groups$groups
  }
  for(x in rownames(r_batchs)){
    r_batchs[x,"SE"]=sd(results[results$batchs==x,"result"],na.rm=T)/sqrt(length(results[results$batchs==x,"result"]))
    r_batchs[x,"Batch"]=x
  }
  colnames(r_batchs)[1]="Accuracy"
  p4=plots(r_batchs)

  if(length(unique(results$losses))==1){
    r_losses=data.frame("result"=mean(results[,"result"],na.rm=T),"groups"="a")
    rownames(r_losses)=results$losses[1]
  }else{
    anova=aov(result~losses,data=results[,c("losses","result")])
    groups=HSD.test(anova,"losses")
    r_losses=groups$groups
  }
  for(x in rownames(r_losses)){
    r_losses[x,"SE"]=sd(results[results$losses==x,"result"],na.rm=T)/sqrt(length(results[results$losses==x,"result"]))
    r_losses[x,"Loss"]=x
  }
  colnames(r_losses)[1]="Accuracy"
  p5=plots(r_losses)

  if(length(unique(results$metrics))==1){
    r_metrics=data.frame("result"=mean(results[,"result"],na.rm=T),"groups"="a")
    rownames(r_metrics)=results$metrics[1]
  }else{
    anova=aov(result~metrics,data=results[,c("metrics","result")])
    groups=HSD.test(anova,"metrics")
    r_metrics=groups$groups
  }
  for(x in rownames(r_metrics)){
    r_metrics[x,"SE"]=sd(results[results$metrics==x,"result"],na.rm=T)/sqrt(length(results[results$metrics==x,"result"]))
    r_metrics[x,"Metric"]=x
  }
  colnames(r_metrics)[1]="Accuracy"
  p6=plots(r_metrics)

  if(length(unique(results$loss_weights))==1){
    r_loss_weights=data.frame("result"=mean(results[,"result"],na.rm=T),"groups"="a")
    rownames(r_loss_weights)=results$loss_weights[1]
  }else{
    anova=aov(result~loss_weights,data=results[,c("loss_weights","result")])
    groups=HSD.test(anova,"loss_weights")
    r_loss_weights=groups$groups
  }
  for(x in rownames(r_loss_weights)){
    r_loss_weights[x,"SE"]=sd(results[results$loss_weights==x,"result"],na.rm=T)/sqrt(length(results[results$loss_weights==x,"result"]))
    r_loss_weights[x,"Loss Weight"]=x
  }
  colnames(r_loss_weights)[1]="Accuracy"
  p7=plots(r_loss_weights)

  #anovas
  if(is.null(MT)){
    r_results=anova_split(results,reps)
  }else{
    r_results=anova_split(results,reps,traits=MT)
  }

  p8 <- ggplot() +
    theme_void() +
    theme(plot.background = element_rect(fill = "white", color = NA),
          panel.background = element_rect(fill = "white", color = NA))

  print(plot_grid(plot_grid(plot_grid(p1, p2, ncol = 2), plot_grid(p3, p4, ncol = 2), plot_grid(p7, p8, ncol = 2), ncol = 1, rel_heights = c(1, 1, 1)), plot_grid(p6, p5, ncol = 1), ncol = 2, rel_widths = c(2, 1)))
  if(!is.null(name_plot)){
    pdf(paste(name_plot,".pdf",sep=""))
    print(plot_grid(plot_grid(plot_grid(p1, p2, ncol = 2), plot_grid(p3, p4, ncol = 2), plot_grid(p7, p8, ncol = 2), ncol = 1, rel_heights = c(1, 1, 1)), plot_grid(p6, p5, ncol = 1), ncol = 2, rel_widths = c(2, 1)))
    dev.off()
  }
  return(list(r_activations,r_optimizers,r_epochs,r_batchs,r_losses,r_metrics,r_loss_weights,r_results))
}
